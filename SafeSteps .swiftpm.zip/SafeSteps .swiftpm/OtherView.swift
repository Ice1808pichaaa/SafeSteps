//
//  OtherView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 29/12/2565 BE.
//

import SwiftUI

struct OtherView: View {
    //create a variable
    @State private var showDeveloperView  = false
    
    var body: some View{
        ZStack{//open zstack
            Color.init(red: 87/255, green: 155/255, blue: 177/255)
            ScrollView{
                VStack (alignment: .center){//open vstack
                    Image(systemName: "book")
                        .font(.system(size: 100))
                        .foregroundColor(.white)
                    Text("*Why do we have to be able to stand on one leg?*")
                        .foregroundColor(.init(red: 225/255, green: 215/255, blue: 198/255))
                        .font(.system(size: 30))
                        .fontWeight(.bold)
                        .padding(10)
                    Text("Being able to stand on one leg for 15 seconds or longer is a sign of good balance and can be a helpful indicator of lower fall risk in older adults.")
                        .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        .frame(width: 320, height: 100)
                        .padding(15)
                        .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                        .cornerRadius(20)
                        .padding(10)
                    VStack {
                        Text("Potential benefits")
                            .fontWeight(.bold)
                            .font(.system(size: 25))
                            .padding(5)
                        Text("1.Improved balance and stability ")
                            .foregroundColor(.red)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Text("\t The ability to stand on one leg requires good balance and stability, and practicing this skill can help improve those abilities over time. Improved balance and stability can help reduce the risk of falls.")
                            .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        Text("2.Better coordination and reaction time")
                            .foregroundColor(.red)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(5)
                        Text("\t Standing on one leg requires coordinated movements and quick reactions to maintain balance. Practicing this task can help improve these abilities, which can also help reduce fall risk.")
                            .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        Text("3.Greater confidence")
                            .foregroundColor(.red)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(5)
                        Text("\t Being able to stand on one leg for 15 seconds or longer can be a confidence booster for older adults, as it demonstrates a level of physical ability and can increase feelings of self-efficacy. Increased confidence can lead to greater engagement in physical activity, which can also help reduce fall risk.")
                            .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        Text("4.Early detection of balance issues")
                            .foregroundColor(.red)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(5)
                        Text("\t If an older adult is unable to stand on one leg for 15 seconds or longer, it may be a sign of balance issues or other underlying health concerns that could increase fall risk. Detecting these issues early can allow for earlier intervention and treatment to reduce the risk of falls.")
                            .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        Spacer()
                        
                    }
                    .frame(width: 320, height: 800)
                    .padding(15)
                    .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                    .cornerRadius(20)
                    .padding(10)
                    VStack{
                        Text("Suggestion")
                            .fontWeight(.bold)
                            .font(.system(size: 25))
                            .padding(5)
                        Text("\tAfter you have done all of the processes in this application you still have to keep your body healthy by Get Active, Eating healthy food, don't be stressed, getting plenty of rest, etc. And keep practicing what you have learned from this application. :)")
                            .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        
                    }
                    .frame(width: 320, height: 220)
                    .padding(15)
                    .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                    .cornerRadius(20)
                    .padding(10)
                    
                    VStack{
                        Text("Why do we have to control the breath while doing balance exercise?")
                            .fontWeight(.bold)
                            .font(.system(size: 20))
                            .padding(5)
                        Text("\t Most people always stop breathing while doing balance exercises. Holding your breath can actually make it more difficult to maintain your body balance, as it can cause tension in your muscles and make it harder to focus on the task at hand. Controlling your breathing while doing balance exercises can help you to stabilize your body, focus your mind, and relax your muscles, all of which can improve your ability to maintain your balance. In this application, I have designed the rate of inhalation to be suitable while doing balance exercises with animation and sound.")
                            .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                        
                    }
                    .frame(width: 320, height: 480)
                    .padding(15)
                    .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                    .cornerRadius(20)
                    .padding(10)
                    
                    Button(action: {
                        self.showDeveloperView.toggle()
                    }){
                        Text("About Developer")
                            .font(.system(size: 23))
                            .fontWeight(.bold)
                            .frame(width: 250, height: 50)
                            .background(Color.init(red: 225/255, green: 215/255, blue: 198/255))
                            .foregroundColor(.black)
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $showDeveloperView){
                        if #available(iOS 16.0, *){
                            DeveloperView()
                                .presentationDetents([.fraction(0.25), .fraction(1.5)])
                        }
                        else{
                            DeveloperView()
                        }
                    }
                }//close vstack
                .foregroundColor(.green)
            }
        }//close zstack
    }
}
    
    struct OtherView_Previews: PreviewProvider {
        static var previews: some View {
            OtherView()
        }
    }
