//
//  PracSecview.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 3/2/2566 BE.
//

import SwiftUI

struct PracSecView: View {
    var body: some View {
        VStack{
            Text("Practice Level 2")
                .fontWeight(.bold)
            Text("Semi-Tandem Stand")
                .fontWeight(.bold)
            Text("Instruction: Find a sturdy chair without wheels or use counter space in the kitchen for support initially. Then, move one foot forward to bring your foot into a stride stance. Once you feel steady, slowly let go of the chair. Try to maintain balance in this position for 30 seconds. Then, try to do the same with the other foot forward. If you can do it successfully, try to do a full tandem stance with the sturdy chair. Make sure that you feel steady before attempting to do it without a sturdy chair.")
                .font(.system(size: 15))
                .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                .frame(width: 300, height: 230)
                .padding(10)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            HStack{
                Image("pracsecondpic")
                    .resizable()
                    .frame(width: 100, height: 200)
                VStack{
                    Image("foot2.1")
                    Text("Semi Tandem stand")
                        .font(.system(size: 14))
                }
            }
            Text("Don't forget to breathe!!. Always focus to inhale and exhale while exercising.")
                .font(.system(size: 14))
                .foregroundColor(.red)
                .frame(width: 350, height: 50)
                .padding(5)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            Spacer()
        }
    }
}

struct PracSecview_Previews: PreviewProvider {
    static var previews: some View {
        PracSecView()
    }
}
