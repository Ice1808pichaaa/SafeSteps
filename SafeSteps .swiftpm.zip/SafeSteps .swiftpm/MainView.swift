import SwiftUI

struct MainView: View {
    var body: some View {
        VStack {
            TabView{ //opentabview
                HomeView()
                    .tabItem{
                        Label("Home", systemImage: "house")
                    }
                OtherView()
                    .tabItem{
                        Label("Knowledge", systemImage: "book")
                    }
            }//close tebview
        }
    }
}
