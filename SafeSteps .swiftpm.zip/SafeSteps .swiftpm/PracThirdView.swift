//
//  PracThirdView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 3/2/2566 BE.
//

import SwiftUI

struct PracThirdView: View {
    var body: some View {
        VStack{
            Text("Practice Level 3")
                .fontWeight(.bold)
            Text("Flamingo Stand")
                .fontWeight(.bold)
            Text("Instruction: To do a one-leg stand, start by standing next to a sturdy chair without wheels or use a counter space in the kitchen for support. Lift one foot off the ground and stand on the other foot. Hold this position for 10 seconds, then switch to the other foot and repeat. Gradually increase the duration of the one-leg stand as you become more comfortable and steady. Make sure to have a stable surface nearby for support if needed.")
                .font(.system(size: 15))
                .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                .frame(width: 300, height: 200)
                .padding(10)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            HStack{
                Image("practhirdpic")
                    .resizable()
                    .frame(width: 180, height: 217)
                VStack{
                    Image("foot3")
                    Text("One leg stand")
                        .font(.system(size: 14))
                }
            }
            Text("Don't forget to breathe!!. Always focus to inhale and exhale while exercising.")
                .font(.system(size: 14))
                .foregroundColor(.red)
                .frame(width: 350, height: 50)
                .padding(5)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            Spacer()
        }
    }
}

struct PracThirdView_Previews: PreviewProvider {
    static var previews: some View {
        PracThirdView()
    }
}
