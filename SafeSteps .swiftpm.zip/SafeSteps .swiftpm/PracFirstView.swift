//
//  PracFirstView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 3/2/2566 BE.
//

import SwiftUI

struct PracFirstView: View {
    var body: some View {
        VStack{
            Text("Practice Level 1")
                .fontWeight(.bold)
            Text("Normal Standing")
                .fontWeight(.bold)
            Text("Instruction: Find a sturdy chair without wheels or use a counter space in the kitchen for support initially. Begin by standing with some space between your feet. Once you have gained stability, bring your feet together as shown in the picture below. Try to maintain the feet-together stance with support for 30 seconds, and then try without support.")
                .font(.system(size: 15))
                .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                .frame(width: 300, height: 180)
                .padding(10)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            HStack{
                Image("pracfirstpic")
                    .resizable()
                    .frame(width: 150, height: 250)
                VStack{
                    Image("foot1")
                    Text("Place your feet like this")
                        .font(.system(size: 14))
                }
            }
            Text("Don't forget to breathe!!. Always focus to inhale and exhale while exercising.")
                .font(.system(size: 14))
                .foregroundColor(.red)
                .frame(width: 350, height: 50)
                .padding(5)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            Spacer()
        }
    }
}

struct PracFirstView_Previews: PreviewProvider {
    static var previews: some View {
        PracFirstView()
    }
}
