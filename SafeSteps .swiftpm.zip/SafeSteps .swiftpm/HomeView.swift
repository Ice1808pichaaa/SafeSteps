//
//  ContentView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 29/12/2565 BE.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView{
            ZStack{
                Color.init(red: 225/255, green: 215/255, blue: 198/255)
                    VStack (alignment:.center){
                            Text("SafeSteps")
                                .font(.title)
                                .fontWeight(.bold)
                                .font(.title2)
                                .fontWeight(.bold)
                            Image("homepic")
                                .frame(width: 150, height: 350)
                        NavigationLink(destination: QuickStartGuideView()){
                            Text("Let's get start")
                                .font(.system(size: 23))
                                .fontWeight(.bold)
                                .frame(width: 300, height: 70)
                                .background(Color(red: 36/255, green: 55/255, blue: 99/255))
                                .foregroundColor(.white)
                                .cornerRadius(100)
                        } //close navlink
                    } //close vstack
                    .background(Color.white)
                    .cornerRadius(30)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color(.sRGB, red: 100/255, green: 100/255, blue: 100/255, opacity: 0)))
                    
            }
            .navigationTitle("Home Screen")
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
