//
//  quickstartguide.swift
//  SafeSteps
//
//  Created by Picha Jetsadapattarakul on 3/4/2566 BE.
//

import SwiftUI

struct QuickStartGuideView: View {
    var body: some View {
        Text("Quick Start Guide")
            .fontWeight(.bold)
        Spacer()
        Image("guidepic")
            .resizable()
        NavigationLink(destination: FirstView()){
            Text("Next")
                .font(.system(size: 23))
                .fontWeight(.bold)
                .frame(width: 150, height: 100)
                .background(Color(red: 36/255, green: 55/255, blue: 99/255))
                .foregroundColor(.white)
                .cornerRadius(100)
        } //close navlink1

    }
}

struct QuickStartGuideView_Previews: PreviewProvider {
    static var previews: some View {
        QuickStartGuideView()
    }
}
