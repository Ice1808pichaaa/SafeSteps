//
//  DeveloperView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 30/12/2565 BE.
//

import SwiftUI

struct DeveloperView: View {
    var body: some View {
        ZStack {
            Color.init(red: 225/255, green: 215/255, blue: 198/255)
            VStack{
                Image("developer")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white, lineWidth: 5))
                    .shadow(radius: 15)
                    .frame(width: 300, height: 300, alignment: .center)
                Text("HI! Everyone.\nMy name is Picha Jetsadapattarakul.\nI am currently a grade 11 student at Assumption College Thonburi\nwho really interested in many field of programing such as Machine Learning, Data Science, Application Development, Web Development etc.")
                    .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                    .frame(minWidth: 0, maxWidth: 300, minHeight: 100)
                    .padding(25)
                    .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                    .cornerRadius(20)
                    .padding(10)
                Text("Enjoy using this app and I hope this app can help reduce falling in elderly.")
                    .foregroundColor(Color(red: 20/255, green: 66/255, blue: 114/255))
                    .frame(minWidth: 0, maxWidth: 300, minHeight: 70)
                    .padding(25)
                    .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                    .cornerRadius(20)
            }
            
        }
    }
}

struct DeveloperView_Previews: PreviewProvider {
    static var previews: some View {
        DeveloperView()
    }
}
