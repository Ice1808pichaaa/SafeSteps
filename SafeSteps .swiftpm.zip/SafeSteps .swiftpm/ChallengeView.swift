//
//  ChallengeView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 3/2/2566 BE.
//

import SwiftUI

struct ChallengeView: View {
    var body: some View {
        VStack{
            Text("Challenge")
                .fontWeight(.bold)
            Text("Single leg reach forward")
                .fontWeight(.bold)
            Text("!!!! This is very advance make sure that you with some one that can support you !!!!")
                .font(.system(size: 14))
                .foregroundColor(.red)
                .frame(width: 350, height: 50)
                .padding(8)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            VStack{
                Text("Instruction: After you have enough balance and stability, let's try a more advanced exercise to improve your body balance and stability to the next level. First, stand on one leg and slowly reach forward with the support of the other leg (this is very important!). Do this exercise for as long as you can, but don't overdo it.")
                    .font(.system(size: 15))
                    .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                Text("Safety come first!!!")
                    .font(.system(size: 15))
                    .foregroundColor(.red)
            }
            .frame(width: 300, height: 180)
            .padding(10)
            .background(Color(red: 235/255, green: 235/255, blue: 235/255))
            .cornerRadius(20)
            HStack{
                Image("challengepic")
                    .resizable()

            }
            Text("Don't forget to breathe!!. Always focus to inhale and exhale while exercising.")
                .font(.system(size: 14))
                .foregroundColor(.red)
                .frame(width: 350, height: 50)
                .padding(5)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            Spacer()
        }
            
    }
}

struct ChallengeView_Previews: PreviewProvider {
    static var previews: some View {
        ChallengeView()
    }
}
