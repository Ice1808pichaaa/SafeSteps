//
//  ThirdView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 29/12/2565 BE.
//

import SwiftUI
import AVFoundation

struct SecondView: View {
    //Timer
    @State var countDownTimer = 15
    @State var timerRunning = false
    //Timer button
    @State var hideStartButton : Bool = false
    @State var hideResetButton : Bool = true
    //animation
    @State private var heartChange = false
    //sound
    @State private var cycleCount = 0
    let synthesizer = AVSpeechSynthesizer()
    let speechTexts = ["Breath In", "Breath Out"]
    @State private var speechTimer: Timer?
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var body: some View {
        VStack (alignment:.center) {
            Text("Level2")
                .fontWeight(.bold)
            Text("Tandem Stand")
                .fontWeight(.bold)
                .padding(20)
            HStack{
                VStack {
                    Image(systemName: "lungs.fill")
                        .font(.system(size: 100))
                        .foregroundColor(.blue)
                        .scaleEffect(heartChange ? 1.0 : 0.25)
                        .padding(10)
                    Text("\(countDownTimer)")
                        .onReceive(timer) { _ in
                            if countDownTimer > 0 && timerRunning {
                                countDownTimer -= 1
                            } else{
                                timerRunning = false
                            }
                        }
                        .font(.system(size: 80, weight: .bold))
                        .foregroundColor(.white)
                        .opacity(0.80)
                        .frame(width: 150, height: 150)
                        .background(Color(red: 43/255, green: 52/255, blue: 103/255))
                        .cornerRadius(60)
                    
                    //timer button
                    if !hideStartButton {
                        Button(action: {
                            self.timerRunning = true
                            self.hideStartButton.toggle()
                            self.hideResetButton.toggle()
                            withAnimation(.linear(duration: 4).repeatCount(4)) {
                                self.heartChange = true
                            }
                            startBreathing()
                        }){
                            HStack{
                                Image(systemName: "speaker.wave.2.fill")
                                    .font(.system(size: 25))
                                Text("Start")
                                    .fontWeight(.bold)
                            }
                            .foregroundColor(.white)
                            .frame(width: 150, height: 75)
                            .background(Color(red: 16/255, green: 161/255, blue: 157/255))
                            .cornerRadius(20)
                        }
                    }
                    if !hideResetButton{
                        Button(action:{
                            self.timerRunning = false
                            self.hideStartButton.toggle()
                            self.hideResetButton.toggle()
                            self.countDownTimer = 15
                            self.cycleCount = 0
                            withAnimation(.linear(duration: 0).repeatCount(0)) {
                                self.heartChange = false
                            }
                            self.speechTimer?.invalidate()
                            self.speechTimer = nil

                        }){
                            Text("Reset")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .frame(width: 150, height: 75)
                                .background(Color(red: 84/255, green: 3/255, blue: 117/255))
                                .cornerRadius(20)
                        }
                    }
                } //close vstack
                VStack{
                    Image("secondpic")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width:200)
                    Image("foot2")
                    Text("Place your feet like this")
                        .font(.system(size: 14))
                } //vstack2
            } //close hstack
            
            Spacer()
            HStack {
                NavigationLink(destination: PracSecView()){
                    Text("Practice")
                        .font(.system(size: 23))
                        .fontWeight(.bold)
                        .frame(width: 150, height: 100)
                        .background(Color(red: 255/255, green: 110/255, blue: 49/255))
                        .foregroundColor(.white)
                        .cornerRadius(100)
                } //close navlink1
                .simultaneousGesture(TapGesture().onEnded({
                    self.timerRunning = false
                    self.hideStartButton = false
                    self.hideResetButton = true
                    self.countDownTimer = 15
                    self.cycleCount = 0
                    withAnimation(.linear(duration: 0).repeatCount(0)) {
                        self.heartChange = false
                    }
                    self.speechTimer?.invalidate()
                    self.speechTimer = nil
                }))
                .padding(20)
                NavigationLink(destination: ThirdView()){
                    Text("Next")
                        .font(.system(size: 23))
                        .fontWeight(.bold)
                        .frame(width: 150, height: 100)
                        .background(Color(red: 36/255, green: 55/255, blue: 99/255))
                        .foregroundColor(.white)
                        .cornerRadius(100)
                }
                .simultaneousGesture(TapGesture().onEnded({
                    self.timerRunning = false
                    self.hideStartButton = false
                    self.hideResetButton = true
                    self.countDownTimer = 15
                    self.cycleCount = 0
                    withAnimation(.linear(duration: 0).repeatCount(0)) {
                        self.heartChange = false
                    }
                    self.speechTimer?.invalidate()
                    self.speechTimer = nil
                }))
            }
        } //close vstack
    }
    func startBreathing() {
        let speechUtterance = AVSpeechUtterance(string: speechTexts[0])
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
        speechUtterance.rate = 0.5
        
        synthesizer.speak(speechUtterance)
        
        speechTimer = Timer.scheduledTimer(withTimeInterval: 4, repeats: true) { timer in
            cycleCount += 1
            if cycleCount == 6 || countDownTimer <= 0 {
                synthesizer.stopSpeaking(at: .immediate)
                self.speechTimer?.invalidate()
                self.speechTimer = nil
                return
            }
            let index = cycleCount % 2
            let speechUtterance = AVSpeechUtterance(string: speechTexts[index])
            speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
            speechUtterance.rate = 0.5
            synthesizer.speak(speechUtterance)
        }
    }
    
}


struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView()
    }
}
