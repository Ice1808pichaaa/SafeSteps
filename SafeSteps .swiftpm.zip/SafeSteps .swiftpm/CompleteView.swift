//
//  SecondView.swift
//  falling prevention
//
//  Created by Picha jetsadapattarakul on 29/12/2565 BE.
//

import SwiftUI

struct CompleteView: View {
    var body: some View {
        VStack (alignment:.center){
            Text("Congratulations!!!")
                .fontWeight(.bold)
            Text("🎉You did it!!🎉 \nI am delighted to offer my sincere congratulations on your successful completion to improve your balance and stability. Your efforts have not gone unnoticed, being able to stand on one leg for 15 seconds or longer is a sign of good balance and can provide several benefits for older adults in terms of reducing fall risk.")
                .foregroundColor(Color(red: 30/255, green: 116/255, blue: 200/255))
                .frame(minWidth: 0, maxWidth: 300, minHeight: 100)
                .padding(20)
                .background(Color(red: 235/255, green: 235/255, blue: 235/255))
                .cornerRadius(20)
            Image("con3")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width:300, height:200)
            NavigationLink(destination: ChallengeView()){
                HStack {
                    Image("con1")
                    Text("Challenge")
                        .font(.system(size: 23))
                        .fontWeight(.bold)
                        .frame(width: 150, height: 100)
                        .background(.orange)
                        .foregroundColor(.white)
                        .cornerRadius(100)
                    Image("con2")
                }
            } //close navlink1
        }
    }
}

struct FirstView_Previews: PreviewProvider {
    static var previews: some View {
        CompleteView()
    }
}
